<!DOCTYPE HTML>
<html>
<head>
<link rel="icon" href="photos\NssLogo.png" type="image/x-icon">
</head>

<?php

require 'authentication.php'; 
$user_name = $_SESSION['name'];
$page_name="Edit Task";
include("sidebarr.php");
?>
<style>
p{
	font-size:20px;
}
img{
	margin-left:0px;
}

table,th,td{

border:1px solid black;
}
#c{
	text-align:center;

}
#a{
	text-align:center;
	background-color:#ffff33;
}
</style>
 <div class="row">
      <div class="col-md-12" >
        <div class="well well-custom">
          <div class="gap"></div>
 <center ><h1>
 <div class="row">
 
<div class="gap"></div>

<div class="gap"></div>
  <div class="col-md-12">

    <div class="well">
	
      <div class="row">
	  
	  <img src="photos/NssLogo.png" height ="60px" width="60px">
	  National Service Scheme(NSS) 
	  </h1></center><p>Jai Hind.</p>
	  <p>The National Service Scheme (NSS) is a Central Sector Scheme of Government of India, Ministry of Youth Affairs & Sports.
	  It provides opportunity to the student youth of 11th & 12th Class of schools at +2 Board level and student youth of Technical Institution, Graduate & Post Graduate 
	  at colleges and University level of India to take part in various government led community service activities & programmes.The sole aim of the NSS is to provide hands 
	  on experience to young students in delivering community service. Since inception of the NSS in the year 1969, the number of students strength increased from 40,000 
	  to over 3.8 million up to the end of March 2018 students in various universities, colleges and Institutions of higher learning have volunteered to take part in various community
	  service programmes</p>
	  <h3>Meaning Of NSS Badge</h3>
	  <p>All the youth volunteers who opt to serve the nation through the NSS led community service wear the NSS badge with pride and a sense of responsibility towards helping needy.

The Konark wheel in the NSS badge having 8 bars signifies the 24 hours of a the day, reminding the wearer to be ready for the service of the nation round the clock i.e. for 24 hours.

Red colour in the badge signifies energy and spirit displayed by the NSS volunteers.

The Blue colour signifies the cosmos of which the NSS is a tiny part, ready to contribute its share for the welfare of the mankind.</p>
<strong><h3>Motto Of NSS </h3></strong>
<p>
<strong>NOT ME BUT YOU</strong>
</p>
<h1 id="c">Core Members 2022-23</h1>
<table id="c" align="center"style="width:50%" >
<tr>
<th colspan="3" id="a">Core Team I</th>
</tr>
<tr>
<th id="c">Name</th>
<th id="c">Designation</th>
</tr>
<tr>
<td>Mrs. Jigna Vyas</td>
<td>Pogram Officer</td>
</tr>

<tr>
<td>Dr. Ranjana Yavagal</td>
<td>Pogram Officer</td>
</tr>

<tr>
<td>Dr. Sanjay Mishra</td>
<td>Asst. Pogram Officer</td>
</tr>

<tr>
<td>Mr. Manoj Singh</td>
<td>Asst. Pogram Officer</td>
</tr>

<tr>
<td>Ms. Khushi </td>
<td>Asst. Pogram Officer</td>
</tr>

<tr>
<td>Mr. Saurabh </td>
<td>Asst. Pogram Officer</td>
</tr>

<tr >
<th colspan="3" id="a">Core Team II</th>
</tr>

<tr>
<th id="c">Name</th>
<th id="c">Designation</th>
</tr>

<tr>
<td id="c">Khushi Jagad</td>
<td id="c">Leader</td>
</tr>

<tr>
<td id="c">Daksh Jogi</td>
<td id="c">Leader</td>
</tr>

<tr>
<td id="c">Ashirvaad Bhat</td>
<td id="c">Sub Leader</td>
</tr>

<tr>
<td id="c">Om Sharma</td>
<td id="c">Sub Leader</td>
</tr>

<tr>
<td id="c">Pratham Parmar</td>
<td id="c">Sub Leader</td>
</tr>

<tr>
<td id="c">Vanita Parmar</td>
<td id="c">Sub Leader</td>
</tr>

<tr>
<td id="c">Sanajana Parker</td>
<td id="c">Sub Leader</td>
</tr>

<tr>
<td id="c">Janvi Shirke</td>
<td id="c">Sub Leader</td>
</tr>

</table>

      </div></div>
  </div>
</div>
<div>

</html>